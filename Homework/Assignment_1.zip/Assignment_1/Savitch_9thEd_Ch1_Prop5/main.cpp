/* 
 * File:   main.cpp
 * Author: Hector Espinoza
 * Created on June 26, 2015, 7:32 PM
 * Purpose: To input a character and outputs any character on the letter c
 */
 
 //System Libraries
 #include <iostream>//File I/O
 #include <string>
 using namespace std; //std namespace -> iostream
 
 //User Libraries
 
 //Global constants
 
 //Function Prototypes
 
 //Execution Begins Here!
 
 int main(int argc, char** argv) {
 
 //Declare Variables Here
 string x;    //To allow any character to be inputed then outputted
 
 //Input Values Here
 
 cout<<"Input any character from the keyboard."<<endl;
 cin>>x;   //Input any character 
 
 
 //Process Input Here
 
 //Output Unknowns Here
 
 cout<<"  "<<x<<x<<x<<endl;
 cout<<" "<<x<<"  "<<x<<endl;
 cout<< x<<endl;
 cout<< x<<endl;
 cout<< x<<endl;
 cout<< x<<endl;
 cout<< x<<endl;
 cout<<" "<<x<<"  "<<x<<endl;
 cout<<"  "<<x<<x<<x<<endl;
 //Exit Stage Right!

 return 0;
}