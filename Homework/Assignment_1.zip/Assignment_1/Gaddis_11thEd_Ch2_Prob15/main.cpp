/* 
 * File:   main.cpp
 * Author: Hector Espinoza
 * Created on June 26, 2015, 5:01 PM
 * Purpose: Triangle Pattern
 */
 
//System Libraries
#include <iostream>  //File I/O
using namespace std; //std namespace -> iostream
 
//User Libraries
 
//Global constants
 
//Function Prototypes
 
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables Here
 
    //Input Values Here
 
    //Process Input Here
 
    //Output Unknowns Here
    cout<<"   *"<<endl;
    cout<<"  ***"<<endl;
    cout<<" *****"<<endl;
    cout<<"*******"<<endl;
    
    //Exit Stage Right!
    return 0;
}
