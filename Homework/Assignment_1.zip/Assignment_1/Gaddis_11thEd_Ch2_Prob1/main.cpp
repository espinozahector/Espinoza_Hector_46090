/* 
 * File:   main.cpp
 * Author: Hector Espinoza
 * Created on June 26, 2015, 5:01 PM
 * Purpose: Multiply the speed and time to get the sum
 */
 
//System Libraries
#include <iostream>  //File I/O
using namespace std; //std namespace -> iostream
 
//User Libraries
 
//Global constants
 
//Function Prototypes
 
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables Here
    float speed=20; //Speed
    float time=10;  //Time
    float dist;     //Distance
 
    //Input Values Here
 
    //Process Input Here
    dist=speed*time; //Speed * Time=Distance
 
    //Output Unknowns Here
    cout<<"The Distance = "<<dist<<endl;
    
    //Exit Stage Right!
    return 0;
}