
/* 
 * File:   main.cpp
 * Author: Hector Espinoza
 * Created on June 26, 2015, 6:26 PM
 * Purpose: Program that prints out "CS!"
 */
 
//System Libraries
#include <iostream>  //File I/O
using namespace std; //std namespace -> iostream
 
//User Libraries
 
//Global constants
 
//Function Prototypes
 
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables Here
 
    //Input Values Here
 
    //Process Input Here
 
    //Output Unknowns Here
    cout<<"*************************************************"<<endl;
    cout<<" "<<endl;
    cout<<"                C C C       S S S S    !!"<<endl;
    cout<<"               C     C     S       S   !!"<<endl;
    cout<<"              C           S            !!"<<endl;
    cout<<"             C             S           !!"<<endl;
    cout<<"             C              S S S S    !!"<<endl;
    cout<<"             C                     S   !!"<<endl;
    cout<<"              C                     S  !!"<<endl;
    cout<<"               C     C     S       S    "<<endl;
    cout<<"                C C C       S S S S    00"<<endl;
    cout<<" "<<endl;
    cout<<"*************************************************"<<endl;
    cout<<"       Computer Science is Cool Stuff!!!"<<endl;
    //Exit Stage Right!
    return 0;
}