/* 
 * File:   main.cpp
 * Author: Hector Espinoza
 *Created on June 23, 2015, 12:51 PM
 * Purpose: Homework, Energy Drinkers
 */

//system Libraries
#include <iostream> //I/O Library
 
using namespace std; //Namespace for iostream
 
//User Libraries
 
//Global Constants
 
//Function Prototype 

//Execute Begins Here!
int main(int argc, char** argv) {
    //Declare Variables 
    unsigned short csurv=1247; 
    unsigned short nEDrnks;
    unsigned short nCDrnks;
    float pEDrnks=0.14f;
    float pcDrnks=0.64f;
    
    nEDrnks=csurv*pEDrnks
    nCDrnks=nEDrnks*pCDrnks
     cout<<"Number of Energy Drinkers= "<<nEDrnks<<endl;
     cout<<"Number of Citrus Drinkers= "<<nCDrnks<<endl;
    return 0;
}

